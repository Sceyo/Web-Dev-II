

import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './Navbar'

export default function Profile({props}) {


    return (
        <>
        <Navbar/>        
         <div><h1>Profile Page</h1>
         <h2>Lord, make me an instrument of your peace: where there is hatred, let me sow love; where there is injury, pardon; where there is doubt, faith; where there is despair, hope; where there is darkness, light; where there is sadness, joy.</h2>
         </div>

        </>
    );
}

