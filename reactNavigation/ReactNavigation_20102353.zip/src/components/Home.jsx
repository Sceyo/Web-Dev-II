

import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './Navbar'

export default function Home({props}) {


    return (
        <>
        <Navbar/>
         <div><h1>Home Page</h1>
            <h2>Ang bayan ko’y tanging ikaw
Pilipinas kong mahal
Ang puso ko at buhay man
Sa iyo’y ibibigay
Tungkulin ko’y gagampanan
Na lagi kang paglingkuran
Ang laya mo’y babantayan
Pilipinas kong hirang

Bayan sa silanga’y hiyas
Pilipinas kong mahal
Kami’y iyo hanggang wakas
Pilipinas kong mahal
Mga ninuno naming lahat
Sa iyo’y naglingkod ng tapat
Ligaya mo’y aming hangad
Pilipinas kong mahal</h2>
         
         </div>

        </>
    );
}

