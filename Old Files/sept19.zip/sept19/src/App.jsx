import './App.css'
import Header from './Components/Header'
import Navbar from './Components/Menus'
import Head from './Components/Navbar'

function App() {
 

  return (
    <>
      <Head/>
    </>
  )
}

export default App
