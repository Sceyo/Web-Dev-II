const itemsRoute = require("./itemsRoutes");
const authRoute = require("./authRoutes");

module.exports = {
  itemsRoute,
  authRoute,
};
